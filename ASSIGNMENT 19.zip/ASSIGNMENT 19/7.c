#include<stdio.h>
#include<string.h>
main()
{
int n,i;
char str[100][100];
char str1[100];
printf("Enter the no. of ip address: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d ip address: ",i+1);
 gets(str[i]);
}
for(i=0;i<=n-1;i++)
printf("%s\n",str[i]);










}
