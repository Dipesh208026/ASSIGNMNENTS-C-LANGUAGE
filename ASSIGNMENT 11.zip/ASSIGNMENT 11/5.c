primebetween(int a);
main()
{
int a;
printf("Enter the number : ");
scanf("%d",&a);
primebetween(a);


}




primebetween(int a)
{int x, i= 2, z;
int c=1;

  while(c<=a)
  {
    z = 0;
    x = 1;
    while(x<=i)
    {
      if(i%x == 0)
      {
        z++;

      }
      x++;
    }
    if(z<=2)
    {
	printf(" %d ", i);
	c++;
    }
    i++;
  }
  }
