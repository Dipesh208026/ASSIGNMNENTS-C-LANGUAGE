#include<stdio.h>
main()
{

int *p;
int *q;
int n,j;
int i;
int sum=0;
printf("Enter the no. of data values: ");
scanf("%d",&n);
p=(int*)calloc(n,sizeof(int));

if(p==NULL)
{
    printf("Memory allocation Failed \n");
    return 0;
}

for(i=0;i<=n-1;i++)
{
    scanf("%d",p+i);
}
q=(int*)malloc(sizeof(int));
for(i=0;i<n-1;i++)
{
   for(j=i+1;j<=n-1;j++)
   {
       if(*(p+i)>=*(p+j))
     {
         q=*(p+i);
      *(p+i)=*(p+j);
      *(p+j)=q;
   }
     }
}
printf("Largest element is: %d",*(p+(n-1)));
free(p);
free(q);
}
