main()
{
int b;
  int a;
  printf("Enter a year :");
  scanf("%d",&a);
switch(a)
{


default:

        if(a%4==0)
        {printf(" lEAP YEAR");}
else if(a%1000==0&&a%4000==0)
{
    printf(" lEAP YEAR");
}
    else
       {
           printf("NOT A LEAP YEAR");
       }



}

}
