main()
{
printf("\\n");

}
