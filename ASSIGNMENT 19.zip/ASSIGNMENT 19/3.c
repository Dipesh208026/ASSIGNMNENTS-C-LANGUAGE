#include<stdio.h>
main()
{
 char str[10][100];
 int i;
 int n;
 printf("Enter the no. of words: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d string: ",i+1);
 gets(str[i]);
}

for(i=0;i<=n-1;i++)
printf("%s\n",str[i]);


}
