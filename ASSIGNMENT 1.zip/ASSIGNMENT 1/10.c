int main()
{
int a,b,c;
printf("Enter the date in this format \" DD/MM/YYYY\"" );
scanf("%d/%d/%d",&a,&b,&c);
printf("Day - %d , Month -%d , Year -%d",a,b,c);
}
