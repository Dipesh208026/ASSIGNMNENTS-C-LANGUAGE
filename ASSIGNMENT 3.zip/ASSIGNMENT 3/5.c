main()
{
int a;
int count=0;
printf("Enter the number: ");
scanf("%d",&a);
int result;
while(a>0)
{
a=a/10;
count++;
}
if(count==3)
printf("NUMBER IS THREE DIGIT");
else
printf("NUMBER IS NON-THREE DIGIT");

}
