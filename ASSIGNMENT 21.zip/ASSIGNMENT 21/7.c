#include<stdio.h>
#include<string.h>

struct student input(int);
struct student
{
int class1;
char name[100];
int roll_no;
};

int main()
{
    int n;
printf("Enter the number of students: ");
scanf("%d",&n);
int i;
struct student b2[100];
for(i=0;i<=n-1;i++)
{
   b2[i]=input(i);
}
printf("\n");
for(i=0;i<=n-1;i++)
{
display(b2[i],i);
}
}
struct student input(int i)
{
struct student b1;
printf("Enter the class of the %d student:- ",i+1);
scanf("%d",&b1.class1);
fflush(stdin);
printf("Enter the name of the  %d student:- ",i+1);
fgets(b1.name,30,stdin);
b1.name[strlen(b1.name)-1]='\0';
printf("Enter the roll_no of the %d student:- ",i+1);
scanf("%d",&b1.roll_no);
return b1;
}
void display(struct student b1,int i)
{


    printf("class of the %d student is: %d\n",i+1,b1.class1);
    printf("Name of the %d student is: %s\n",i+1,b1.name);
    printf("Roll_no of the %d student is:  %d\n",i+1,b1.roll_no);

}
