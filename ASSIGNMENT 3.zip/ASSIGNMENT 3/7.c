main()
{
int a,b,c;
printf("Enter the coefficients of a,b,c: ");
scanf("%d%d%d",&a,&b,&c);
int d;
d=b*b-4*a*c;
if(d==0)
{

printf("ROOTS ARE REAL AND EQUAL");

}
else if(d<0)
{printf("ROOTS ARE IMAGINARY ");}
else if(d>0)
{
printf("ROOTS ARE REAL AND DISTINCT");
}




}
