#include<stdio.h>
main()
{

int *p;
p=(int*)malloc(sizeof(int));
p=NULL;
return 0;


}
