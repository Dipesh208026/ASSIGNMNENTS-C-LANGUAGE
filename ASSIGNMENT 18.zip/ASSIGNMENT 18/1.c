#include<stdio.h>
#include<string.h>
int length(char []);
main()
{
char str[100];
printf("Enter the string: ");
fgets(str,20,stdin);

int a=length(str);
printf("%d",a);
}

int length(char str[])
{

int len=strlen(str);
str[len-1]='\0'; // replacing a new line character by null character
return(strlen(str));
}
