main()
{
int i,j;
int k=6;
int m=5;
for(i=1;i<=9;i++)
{
if(i%2!=0)


for(j=1;j<=9;j++)
{
if(i>=1&&i<=7&&j<=5&&j==m)
{
    m--;
    printf("*");

}
else if(i>=3&&i<=7&&j>5&&j==k)
{

    printf("*");
    k++;
    break;

}
else if(i==9)
printf("*");
else
printf(" ");

}

printf("\n");

}

}

