void reverse(int);
main()
{

int a;
printf("Enter the number: ");
scanf("%d",&a);

reverse(a);
}
reverse(int a )
{


if(a==0)
return;
int q,r;
q=a/10;
r=a%10;
a=q;
printf("%d",r);
reverse(a);



}
