int factorial(int i,int j);
void pascal(int a,int columns);
main()
{
int a;
printf("Enter the no. of rows for pascal triangle: ");
scanf("%d",&a);
int columns;
if(a%2==0)
     columns=(2*a)+1;
else
    columns=(2*a)-1;

    pascal(a,columns);
}






void pascal(int a,int columns)

{

int i,j;


int y;
int x=0;



if(a%2==0)
{
 for(i=1;i<=a;i++)
{
    y=0;
for(j=1;j<=columns;j++)
{

if(i%2!=0&&j%2==0&&j<=a+(i-1)&&j>=a-(i-1)||i%2==0&&j%2!=0&&j<=a+i&&j>=a-i)
    {
        int print=factorial(x,y);
        printf("%d",print);
        y++;


    }

else
printf(" ");

}
printf("\n");
x++;
}
}
else if(a%2!=0)
   {
       for(i=1;i<=a;i++)
{
    y=0;
for(j=1;j<=columns;j++)
{

if(i%2==0&&j%2==0&&j<=a+(i-1)&&j>=a-(i-1)||i%2!=0&&j%2!=0&&j<=a+i&&j>=a-i)
{
    int print=factorial(x,y);
        printf("%d",print);
        y++;
}

else
printf(" ");

}
printf("\n");
x++;
}


}















}















int factorial(int i,int j)

{
int n;
int fact1=1;
for(n=i;n>=1;n--)
{
 fact1=n*fact1;
}
int fact2=1;
for(n=j;n>=1;n--)
{
 fact2=n*fact2;

}
if(j==0)
    fact2=1;
int n2=i-j;
int fact3=1;
for(n=n2;n>=1;n--)
{
fact3=n*fact3;
}

int fact4=fact3*fact2;
int factfinal=fact1/fact4;
if(i==0&&j==0)
    factfinal=1;
return(factfinal);

}







