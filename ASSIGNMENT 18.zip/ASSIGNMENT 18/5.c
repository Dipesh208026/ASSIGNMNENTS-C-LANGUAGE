#include<stdio.h>
#include<string.h>
void lower(char [],int);
main()
{
char str[100];
printf("Enter the upper string: ");
gets(str);

int len=strlen(str);
lower(str,len);
}
char t;
void lower(char str[],int len)
{

int i;
int c;
for(i=0;i<=len-1;i++)
{

if(str[i]>='A'&&str[i]<='Z'&&str[i]!=32)
{c=str[i];
int b=c+32;
str[i]=b;
}

}


printf("%s",str);







}
