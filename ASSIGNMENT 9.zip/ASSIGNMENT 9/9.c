main()
{
int a;
printf("Enter any even number:" );
scanf("%d",&a);

switch(a)
{
default:
a=a+1;
printf("%d",a);


}

}
