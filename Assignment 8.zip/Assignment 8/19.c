main()
{

int j,i;
int k=1;
int m=9;
for(i=1;i<=25;i++)
{

if(i%2!=0&&i<=5)

{
k++;
for(j=1;j<=19;j++)
{

if(j<=5+k&&j>=5-k)
printf("*");
else if(j<=15+k&&j>=15-k)
    printf("*");


else
printf(" ");




}
}

else if(i==7)
{
    for(j=1;j<=19;j++)
    {
       if(j>=1&&j<=6)
            printf("*");

       else if(j>=13&&j<=19)
        printf("*");

       else if(j==8)
        printf("My");

       else if(j==9)
        printf("Si");

       else if(j==10)
        printf("r");
         else if(j==11)
        printf("G");

        else
            printf("");

    }
}

else if(i%2!=0&&i>=9)

{
    m--;
    for(j=1;j<=19;j++)
    {
        if(j>=10-m&&j<=10+m)
    printf("*");

    else
        printf(" ");
    }

}
printf("\n");

}



}
