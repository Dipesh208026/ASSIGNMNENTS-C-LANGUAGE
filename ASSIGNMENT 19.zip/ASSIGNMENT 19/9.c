#include<stdio.h>
#include<string.h>
void fact();
main()
{
int n,i,j;
char str[100][100];
char word1[100];
char word2[100];
int out=0;
int a;
printf("Enter the no. of words: ");
 scanf("%d",&n);
fflush(stdin);
int d1,d2;
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d word: ",i+1);
 gets(str[i]);
 }
 char user[100];
 printf("Enter the username: ");
 gets(user);
 for(i=0;i<=n-1;i++)
 {
 if(strcmp(str[i],user)==0)
 {
     fact();
     out=1;
     break;
 }

 }
 if(out==0)
 printf("Username is not matched with the words!!");

 }

 void fact()
 {
 int a,i,fact1;
 printf("Enter the number: ");
 scanf("%d",&a);
 int sum=1;
 for(i=a;i>=1;i--)
 {
sum=sum*i;


 }
 printf("Factorial of a number is: %d\n",sum);



 }
