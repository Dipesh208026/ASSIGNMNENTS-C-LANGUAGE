main()
{
int l=65;
int m;
int i,j;
for(i=1;i<=5;i++)
{
int k=65;
m=l;
for(j=1;j<=17;j++)
{

    if(j>=(9-2*i+1)&&j<=9&&j%2!=0)
{

printf("%c",k);
k++;

}
else if(i>1&&j>10&&j<=6+(2*i+1)&&j%2!=0)
{

    printf("%c",m-1);
    m--;
}
else
    printf(" ");


}
printf("\n");
l++;
}
}
