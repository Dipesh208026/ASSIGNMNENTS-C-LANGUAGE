#include<stdio.h>
main()
{
 char str[10][100];
 int i;
 int n;
 printf("Enter the no. of words: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d string: ",i+1);
 gets(str[i]);
}
printf("\n");
char temp[100];
int j;
int a;
for(i=0;i<n-1;i++)
{


for(j=i+1;j<=n-1;j++)
{
int a= strcmp(str[i],str[j]);
if(a>=0)
{
strcpy(temp,str[i]);
strcpy(str[i],str[j]);
strcpy(str[j],temp);
}
}
}
printf("AFTER SORTING IN DICTIONARY ORDER: \n");
printf("------------------------------------\n");
for(i=0;i<=n-1;i++)
printf("%s\n",str[i]);

















}
