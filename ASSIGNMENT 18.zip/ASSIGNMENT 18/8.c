#include<stdio.h>
#include<string.h>
void count(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
count(str,len);
}
void count(char str[],int len)
{
    if(str[len-1]==32)
        str[len-1]='\0';
    int i;
int count=0;
for(i=0;i<=len-1;i++)
{
if(str[i]==32&&str[i+1]!=32)
{
count++;




}


}
printf("No. of words are: %d",count+1);


}
