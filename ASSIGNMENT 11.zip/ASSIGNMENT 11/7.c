fibonacci(int n);
main()
{
int n;
printf("Enter the number: ");
scanf("%d",&n);

fibonacci(n);
}

fibonacci(int n)
{

int f1=0,f2=1,i;

if(n<1)
    return;
printf("%d\t",f1);

for(i=1;i<=n;i++)
{
printf("%d\t",f2);
int c=f1+f2;
f1=f2;
f2=c;

}


}
