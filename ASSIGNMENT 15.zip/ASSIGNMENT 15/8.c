void unique(int a[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
unique(a,n);

}
void unique(int a[],int n)

{

int temp=0;
int sum=0;
int count;
int i,j;

for(i=0;i<=n-1;i++)
{
count=0;
for(j=0;j<=n-1;j++)
{

if(a[i]==a[j])
{

count++;

}


}
if(count==1)
printf("%d\t",a[i]);
}


}
