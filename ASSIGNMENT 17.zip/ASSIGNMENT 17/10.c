#include<stdio.h>
#include<string.h>

main()
{
    char str[100];
int count;
    printf("Enter the string: ");
    gets(str);

    // calculating length of the string
    int len =strlen(str);

    int i;
    int a[151];
    for(i=0;i<=150;i++)
    {
        a[i]=0;
    }

for(i=0;i<=len-1;i++)
{
    count=str[i];
    a[count]++;

}
for(i=0;i<=150;i++)
{
    if(a[i]!=0)
        printf("Occurence of %c is: %d\n",i,a[i]);
}




}
