main()
{

int n;
printf("Enter the number: ");
scanf("%d",&n);
int i,a,b;
printf("0 1 ");
a=0;
int c;
b=1;
for(i=3;i<=n;i++)
{
c=a+b;
printf(" %d ",c);
a=b;
b=c;



}



}
