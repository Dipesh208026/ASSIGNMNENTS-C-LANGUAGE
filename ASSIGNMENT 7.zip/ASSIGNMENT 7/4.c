main()
{
int a,b;
int x;
printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);
int i;
for(i=1;i<=a && i<=b;i++)
{
if(a%i==0 && b%i==0)
 {x=i;}

}
printf("HCF OF TWO NUMBERS IS  : %d ",x);




}
