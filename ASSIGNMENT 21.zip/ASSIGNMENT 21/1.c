#include<string.h>
#include<stdio.h>
struct employee
{
int id;// member variable
char name[100];
int salary;
}b1;// structure variable

main()
{

    printf("Enter the id of the employee ");
    scanf("%d",&b1.id);
    printf("Enter the name of the employee ");
    fflush(stdin);
    fgets(b1.name,20,stdin);
    b1.name[(strlen(b1.name))-1]='\0';
    printf("Enter the salary of the employee ");
    scanf("%d",&b1.salary);

printf("%d\n",b1.id);
printf("%s\n",b1.name);
printf("%d",b1.salary);

}
