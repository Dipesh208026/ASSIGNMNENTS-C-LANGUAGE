main()
{

int a;
int i=1;
int count=0;
int j=1;
printf("Enter the number: ");
scanf("%d",&a);
while(j<=10)
{
if(a%j==0)
{
count++;

}

j++;

}
if(count==2)
printf("NUMBER IS PRIME ");
else
printf("NUMBER IS NON PRIME ");


}


