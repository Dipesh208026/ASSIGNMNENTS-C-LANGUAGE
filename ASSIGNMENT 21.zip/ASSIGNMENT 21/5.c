#include<stdio.h>
#include<string.h>

struct employee input(int);

struct employee
{
int id;
char name[100];
int salary;
};

int main()
{
    int n;
printf("Enter the number of employees: ");
scanf("%d",&n);
int i;
struct employee b2[100];
for(i=0;i<=n-1;i++)
{
   b2[i]=input(i);
}
printf("\n");
salary(b2,n);
}
struct employee input(int i)
{
struct employee b1;
printf("Enter the id of the %d employee:- ",i+1);
scanf("%d",&b1.id);
fflush(stdin);
printf("Enter the name of the  %d employee:- ",i+1);
fgets(b1.name,30,stdin);
b1.name[strlen(b1.name)-1]='\0';
printf("Enter the salary of the %d employee:- ",i+1);
scanf("%d",&b1.salary);
return b1;
}

void salary(struct employee b3[],int n)
{
struct employee temp;
int i,j;
for(i=0;i<n-1;i++)
{
for(j=i+1;j<=n-1;j++)
{

if(b3[i].salary>=b3[j].salary)
{
    temp=b3[i];
b3[i]=b3[j];
b3[j]=temp;


}
}
}
printf("After sorting according to salaries: ");
printf("\n");

for(i=0;i<=n-1;i++)
{
printf("name -> %s and their salary -> %d \n",b3[i].name,b3[i].salary);

}

}
