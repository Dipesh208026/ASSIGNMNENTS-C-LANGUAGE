float si(float a,float b,float c);
main()
{
    float a,b,c;
printf("Enter the pricipal rate :");
scanf("%f",&a);
printf("Enter the interest rate :");
scanf("%f",&b);
printf("Enter the time :");
scanf("%f",&c);

float d=si(a,b,c);
printf("%.2f",d);
}
float si(float e,float f,float g)
{

float p= e*f*g*0.01;
return(p);




}
