void rotate(int a[],int ,int ,int);
main()
{
int a[100],n,i,c,r,d;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
printf("Enter the rotation no.: ");
scanf("%d",&r);
printf("Enter the rotation sequence :\n Enter 1 for left:\n Enter 2 for right :");
scanf("%d",&d);
rotate(a,n,r,d);

}
void rotate(int a[],int n,int r,int d)
{
int i;
if(d==2)
{
while(r!=0)
{
int temp=a[n-1];

for(i=n-1;i>=0;i--)
{
a[i]=a[i-1];



}
a[0]=temp;
r--;

}
}
else if(d==1)
{
   while(r!=0)
{
int temp=a[0];

for(i=0;i<=n-2;i++)
{
a[i]=a[i+1];



}
a[n-1]=temp;
r--;

}




}

for(i=0;i<=n-1;i++)
{
printf("%d\t",a[i]);

}




  }

