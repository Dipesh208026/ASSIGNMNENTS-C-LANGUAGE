int natural(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int sum=natural(a);
printf("%d",sum);
}
int natural(int a)
{
int q,r;
if(a==0)
    return 0;
    q=a/10;
    r=a%10;
    a=q;
int sum=r+natural(a);
return(sum);

}
