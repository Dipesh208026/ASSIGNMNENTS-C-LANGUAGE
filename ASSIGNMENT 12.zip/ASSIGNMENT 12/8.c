void binary(int);
main()
{

int a;
printf("Enter the number: ");
scanf("%d",&a);

binary(a);




}

void binary(int a)

{
int q;
int r;


if(a==0)
return;
q=a/2;
r=a%2;
a=q;
binary(q);
printf("%d",r);





}
