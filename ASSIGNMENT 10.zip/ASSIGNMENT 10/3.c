evenodd(int b);
main()
{
    int a;
printf("Enter the number: ");
scanf("%d",&a);

int c=evenodd(a);
printf("%d",c);
}

evenodd(int b)
{
int p;
if(b%2==0)
{p=1;
return(p);}
else if(b%2!=0)
{
  p=0;
return(p);
}



}
