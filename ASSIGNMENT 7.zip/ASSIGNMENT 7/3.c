main()
{

int n;
printf("Enter the number: ");
scanf("%d",&n);
if(n==1 || n==0)
printf("YES THIS TERM IS IN FIBONACCI SERIES");

else
{
    int i,a,b;
a=0;
int c;
b=1;
for(i=1;i<=n;i++)
{
c=a+b;
a=b;
b=c;
if(c==n)
    {printf("THIS TERM IS IN FIBONACCI SERIES");
break;
    }

}
if(c==n)
    printf(" ");
else
    printf("THIS TERM IS NOT IN FIBONACCI SERIES");

}
}
