main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a>=0)
printf("POSITIVE");
else
printf("NEGATIVE");



}
