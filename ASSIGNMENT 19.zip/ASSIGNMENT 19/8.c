#include<stdio.h>
#include<string.h>
main()
{
int n,i,j;
char str[100][100];
char word1[100];
char word2[100];
printf("Enter the no. of words: ");
 scanf("%d",&n);
fflush(stdin);
int a,d1,d2;
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d word: ",i+1);
 gets(str[i]);
 }
printf("Enter the 1st word: ");
gets(word1);
printf("Enter the 2nd word: ");
gets(word2);
int len1=strlen(word1);
int len2=strlen(str[0]);
d1=-1;
d2=-1;
for(i=0;i<=1;i++)
{
    for(j=0;j<=n-1;j++)
    {
    if((i==0)&&(strcmp(str[j],word1)==0))
            d1=j;
        else if((i==1)&&(strcmp(str[j],word2)==0))
        d2=j;
    }
}
 printf("\n");
 int final1=d2-d1;
 if(d1==-1&&d2==-1)
    printf("No words match given by you!!");
 else
 printf("MINIMUM DISTANCE IS : %d",final1-1);

 }



