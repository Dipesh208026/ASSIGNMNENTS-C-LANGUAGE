main()
{
int i,j;
int k=-1;
int m=8;
int l;
for(i=1;i<=9;i++)
{
    l=k+1;
if(i%2!=0)
    for(j=1;j<=9;j++)
    {

     if(i==1)
        printf("*");

else if(j==(i+1-j)&&i>1)
    {
        printf("*");
    }

else if(i==3&&j==8)
    {
        printf("*");
    }
else if(i==5&&j==7)
    {
        printf("*");
    }
    else if(i==7&&j==6)
    {
        printf("*");
    }

else
    printf(" ");



    }


k++;
printf("\n");

}



}


