main()
{
int i,n;
int a[10];
printf("Enter the no. of values: ");
scanf("%d",&n);
printf("Enter the 10 numbers :");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
int sum1=0;
int sum=0;
for(i=0;i<=n-1;i++)
{
if(a[i]%2==0)
sum=sum+a[i];
else if(a[i%2!=0])
sum1=sum1+a[i];

}

printf("Odd numbers sum: %d\n",sum1);
printf("Even numbers sum: %d",sum);




}
