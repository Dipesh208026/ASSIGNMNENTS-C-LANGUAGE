main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int result=a&1;
if(result==1)
printf("ODD");6
else
printf("EVEN");




}
