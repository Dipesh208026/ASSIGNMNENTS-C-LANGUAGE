main()
{
int radius;
float area;
printf("Enter the radius of the circle: ");
scanf("%d",&radius);
area=(float)radius*radius*3.14;
printf("Area of circle is %.2f having the radius %d",area,radius);


}
