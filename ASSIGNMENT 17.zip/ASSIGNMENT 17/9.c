main()
{
char str[100];
 printf("Enter the string: ");
 gets(str);
 int len=strlen(str);
 int i,j;
 char c;

 for(i=0;i<len-1;i++)
 {
     for(j=i+1;j<=len-1;j++)
     {
         if(str[i]>=str[j])
         {
            c=str[j];
            str[j]=str[i];
            str[i]=c;
         }
     }


 }

printf("AFTER SORTING THE STRING \n ");
printf("%s",str);

}
