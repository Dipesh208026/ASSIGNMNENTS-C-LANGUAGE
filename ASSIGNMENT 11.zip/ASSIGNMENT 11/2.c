hcf(int a,int b);
main()
{
int a,b;
printf("Enter the 1st number: ");
scanf("%d",&a);
printf("Enter the 2nd number: ");
scanf("%d",&b);
hcf(a,b);


}
hcf(int a,int b)
{
int i,hcf;
for(i=1; i <= a && i <= b; ++i)
    {

        if(a%i==0 && b%i==0)
            hcf = i;
    }
printf("HCF IS %d",hcf);
}



