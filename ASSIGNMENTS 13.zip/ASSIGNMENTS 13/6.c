int factorial(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int fact=factorial(a);
printf("%d",fact);
}
int factorial(int a)
{

if(a==1)
return 1;
int fact=a*factorial(a-1);
return fact;

}
