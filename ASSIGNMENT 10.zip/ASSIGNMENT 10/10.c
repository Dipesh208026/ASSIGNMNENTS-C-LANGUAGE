main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);

prime(a);




}
void prime( int a)
{
int b=2;
while(a>1)
{

if(a%b==0)
{
a=a/b;
printf("%d\t",b);
}
else if(a%b!=0)
{
b++;
a=a/b;
printf("%d\t",b);

}

}



}
