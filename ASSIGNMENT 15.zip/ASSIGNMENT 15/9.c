void merge(int a[],int b[],int n);
main()
{
int a[100],b[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values of 1st array: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
printf("Enter the values of 2nd array: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&b[i]);

}
merge(a,b,n);

}

void merge(int a[],int b[],int n)
{
int c[100];
int j;
int e=2*n;
int d=e/2;

int i;
for(i=0;i<=d-1;i++)
{
c[i]=a[i];

}

for(i=d;i<=e-1;i++)
{
c[i]=b[i-5];

}

printf("MERGED ARRAY: \n");
for(i=0;i<=e-1;i++)
{
printf("%d\t",c[i]);
}
printf("\n");
printf("AFTER SORTING IN DESCENDING ORDER: \n");
int temp;
for(i=0;i<=e-1;i++)
{
    for(j=i+1;j<=e-1;j++)

    {
        if(c[i]>=c[j])
        {
            temp=c[j];
            c[j]=c[i];
            c[i]=temp;

        }



    }



}

for(i=0;i<=e-1;i++)
{
    printf("%d\t",c[i]);

}




}
