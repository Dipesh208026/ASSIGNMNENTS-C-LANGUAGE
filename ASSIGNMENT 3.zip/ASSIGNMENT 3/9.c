main()
{
int a,b,c;
int max;
printf("Enter the FIRST NUMBER: ");
scanf("%d",&a);
printf("Enter the SECOND NUMBER: ");
scanf("%d",&b);
printf("Enter the THIRD NUMBER: ");
scanf("%d",&c);
max=(a>b)?(a>c?a:c):(b>c?b:c);
printf("Maximum number is : %d",max);



}
