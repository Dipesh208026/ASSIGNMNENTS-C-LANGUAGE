main()
{
int i;
for(i=0;i<=4;i++)
{
    printf("MySirG \n");
}



}
