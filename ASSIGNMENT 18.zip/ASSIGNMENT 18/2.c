#include<stdio.h>
#include<string.h>
void reverse(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
reverse(str,len);
}
char t;
void reverse(char str[],int len)
{
int i=0;
int j=len-1;

for(i=0;i<=j;i++)
{
   char t=str[i];
   str[i]=str[j];
   str[j]=t;
   j--;

}
printf("%s",str);

}
