void swap(int *p,int *q);
main()
{
int a,b;
printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);
swap(&a,&b);
printf(" first number is %d\n",a);
printf(" Second number is %d",b);
}

void swap(int *p,int *q)
{
int temp;
temp=*p;//value of a
*p=*q; // value of b assigned to p
*q=temp; // value of a assigned to q


}
