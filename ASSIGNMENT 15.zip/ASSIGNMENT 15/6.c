void reverse(int a[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
reverse(a,n);

}
void reverse(int a[],int n)
{

int i;
for(i=n-1;i>=0;i--)
{
printf("%d\t",a[i]);

}




}
