main()
{
int a;
printf("Enter the number : ");
scanf("%d",&a);
primenumber(a);


}
void primenumber(int a)
{
int y=0;
int x=1;
while(x<=a)

{
if(a%x==0)
{
    y++;
    }
x++;
}

if(y<=2)
printf("PRIME NUMBER ");
else
printf("NOT A PRIME NUMBER");
}
