main()
{
int i,j;
int n=71;
for(i=1;i<=7;i++)
{
int  k=65;
 int l=n;
 int m=70;
for(j=1;j<=25;j++)
{

if(j>=1&&j<=14-(2*i-1)&&j%2!=0)
{printf("%c",k);
k++;}
else if(i>=2&&j>=12+(2*i-1)&&j<=25&&j%2!=0)
{

 printf("%c",l);
 l--;
}

else if(i==1&&j>=14&&j<=25&&j%2!=0)
{
    printf("%c",m);
m--;}
else
printf(" ");

}
n--;
printf("\n");
}


}
