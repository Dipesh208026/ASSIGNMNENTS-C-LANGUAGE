main()
{
int a,last;
printf("Enter the Three digit number: ");
scanf("%d",&a);
int sum=0;
int b=a;
while(a!=0)
{last= a%10;
a=a/10;
int mul=last*last*last;
sum=sum+mul;
}

if(sum==b)
printf("YES! THIS IS ARMSTRONG NUMBER: ");
else
printf("NO! THIS IS NOT ARMSTRONG ");


}
