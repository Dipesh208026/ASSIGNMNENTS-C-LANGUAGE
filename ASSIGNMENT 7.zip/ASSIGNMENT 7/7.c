int main()
{
        int a,b;
    printf("Enter first number: ");
    scanf("%d",&a);
    printf("Enter the Last number: ");
    scanf("%d",&b);

  int x, i= 2, z;


  while(a <= b)
  {
    z = 0;
    x = 1;
    while(x<=a)
    {
      if(a%x == 0)
      {
        z++;

      }
      x++;
    }
if(z==2)
	printf(" %d ", a);
    a++;
  }

}
