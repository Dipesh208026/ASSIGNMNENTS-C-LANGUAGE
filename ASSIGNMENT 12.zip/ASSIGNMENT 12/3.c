main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);

natural(a);

}
void natural(int a)
{

if(a==0)
return;
natural(a-1);
printf("%d\n",2*a-1);





}
