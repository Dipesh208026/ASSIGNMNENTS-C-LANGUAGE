main()
{
int i,j;

for(i=1;i<=9;i++)
{
if(i%2!=0)
{

for(j=1;j<=9;j++)
{
if(j==i&&j%2!=0)
printf("*");

else if(j<=1&&j%2!=0)
    printf("*");
else if(i==9&&j%2!=0)
printf("*");

else
printf(" ");

}
printf("\n");

}

}
}
