main()
{
int a,b,c;
printf("Enter the three numbers: ");
scanf("%d%d%d",&a,&b,&c);


int max;
max=a>b&&a>c?a:(b>a&&b>c?b:c);
printf("%d",max);
}
