// concept of splitting strings and the process is called the TOKENIZATION.
#include<stdio.h>
#include<string.h>
void check(char str[]);
main()
{
int n,i;
char str[100][100];
printf("Enter the no. of ip address: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d ip address: ",i+1);
 gets(str[i]);
 }

 printf("VALID IP ADDRESS ARE: \n");
 printf("-----------------------\n");
 for(i=0;i<=n-1;i++)
 {

     check(str[i]);
 }



 }

void check(char str[])
{
    char str2[100];
    strcpy(str2,str);
    int count=0;
    int x;
    char *str1=strtok(str,".");
int point=0;
    while(str1!=NULL)
    {

        int x=atoi(str1);
        if((x>=0)&&(x<=255))
       count++;
        str1=strtok(NULL,".");
        point++;
    }

    if(count==4&&point==4)
        printf("%s\n",str2);





}
