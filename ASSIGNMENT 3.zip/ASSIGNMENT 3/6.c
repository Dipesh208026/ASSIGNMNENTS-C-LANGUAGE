main()
{
int a,b;
int count=0;
printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the Second number: ");
scanf("%d",&b);
int result;
if(a>b)
{printf("GREATER NUMBER IS %d",a);}
else if(a<b)
{printf("GREATER NUMBER IS %d",b);}
else if(a==b)
{printf("NUMBER IS SAME");}

}
