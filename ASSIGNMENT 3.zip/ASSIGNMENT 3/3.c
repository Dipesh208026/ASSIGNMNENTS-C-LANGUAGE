main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a%2==0)
printf("EVEN");
else
printf("ODD");



}
