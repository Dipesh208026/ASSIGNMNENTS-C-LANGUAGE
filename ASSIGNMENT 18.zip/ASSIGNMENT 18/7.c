#include<stdio.h>
#include<string.h>
void palindrome(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
palindrome(str,len);
}

void palindrome(char str[],int len)
{
int i;
int count=0;
int j=len-1;

for(i=0;i<=j;i++)
{
if(str[i]==str[j])
{count++;
}
j--;

}
if(i==count)
printf("The String is Palindrome ");
else
printf("The String is NOT Palindrome ");





}
