main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a%5==0)
printf("YES , NUMBER IS DIVISIBLE BY 5");
else
printf("NO NUMBER IS NOT DIVISIBLE BY 5");




}
