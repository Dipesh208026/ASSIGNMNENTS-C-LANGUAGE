naturalnumber(int c);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
naturalnumber(a);
}

naturalnumber(int c)
{
int i;
int sum=1;


for(i=1;i<=c;i++)
{

   sum=sum*i;

}
 printf("%d",sum);

}


