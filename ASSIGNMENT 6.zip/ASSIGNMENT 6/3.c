main(){
int i,n;
printf("Enter the number: ");
scanf("%d",&n);
int sum=0;
for(i=0;i<=2*n;i++)
{if(i%2!=0)
   {sum=sum+i;}

}
   printf("Sum is %d",sum);

}
