main(){

int x;
printf("Enter the week day number: ");
scanf("%d",&x);

switch(x)
{

case 1:
printf("I hope you're doing well");
break;

case 2:
printf("i hope yo're having a great week' ");
break;
case 3:
printf("how are you?");
break;
case 4:
printf("Hello ");
break;
case 5:
printf("What about today!");
break;
case 6:
printf("I hope you enjoyed your weekend");
break;
case 7:
printf("What about today's plan..'");
break;
default:
printf("please enter valid week no.");
}



}
