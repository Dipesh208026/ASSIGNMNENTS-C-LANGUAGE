main()
{
char str[100];
 printf("Enter the upper case string: ");
 gets(str);
 int len=strlen(str);
 int i;


 char temp[100];

 for(i=0;i<=len-1;i++)
 {
 temp[i]=str[i];



 }

 printf("%s",temp);




 }
