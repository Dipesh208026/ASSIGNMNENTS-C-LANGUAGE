int sqr(int a);
main()
{
int a;
printf("Enter the  number: ");
scanf("%d",&a);
int d;
d=sqr(a);
printf("%d",d);

}

int sqr(int a)
{

    int c=a*a;
    return(c);
}
