main()
{
int a[10];
int i,n;
printf("Enter the no. of values: ");
scanf("%d",&n);
printf("Enter the numbers: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);
}
int sum=0;
for(i=0;i<=n-1;i++)
{

sum=sum+a[i];
}

printf("Sum of the numbers are: %d",sum);


}
