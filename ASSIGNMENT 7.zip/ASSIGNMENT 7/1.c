main()
{

int n;
printf("Enter the nth number: ");
scanf("%d",&n);
int i,a,b;
if(n==1)
printf("Nth term is 0");
else if(n==2)
{
    printf("Nth term is 1");
}
    else
    {
     a=0;
int c;
b=1;
for(i=3;i<=n;i++)
{
c=a+b;
a=b;
b=c;



}
printf("Nth term is %d",c);
    }

}



