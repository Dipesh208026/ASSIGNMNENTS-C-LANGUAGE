main(){
    char a[10];
printf("Enter the name ");
scanf("%s",a);
printf("\"Hello %s\"",a);



}
