#include<stdio.h>
main()
{
int sum=0;
int *p;
//int j=1;
int i,n;
printf("Enter the no. of data values: ");
scanf("%d",&n);
p=(int*)malloc(n*sizeof(int));
if(p==NULL)
{
    printf("Memory allocation Failed \n");
    return 0;
}
for(i=0;i<=n-1;i++)
{
   // j++;
scanf("%d",p+i);
//p=(int*)realloc(p,j*sizeof(int));
}
//*(p+i)='\0';
for(i=0;i<=n-1;i++)
{

sum=sum+*(p+i);
}
printf("Sum is %d",sum);
free(p);

}
