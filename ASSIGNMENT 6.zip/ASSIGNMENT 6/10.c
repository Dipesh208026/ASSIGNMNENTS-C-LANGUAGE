main()
{
int a;
int last;
printf("Enter the number: ");
scanf("%d",&a);
while(a!=0)
{
last=a%10;
a=a/10;
printf("%d",last);
}




}
