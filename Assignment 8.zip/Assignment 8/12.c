
main()
{
int i,j;
int l=67;
for(i=1;i<=4;i++)
{

int  k=65;
 int m=l;
for(j=1;j<=13;j++)
{

if(j>=2*i-1&&j<=7&&j%2!=0)
{printf("%c",k);
k++;}
else if(i<4&&j>=9&&j<15-(2*i-1)&&j%2!=0)
{

 printf("%c",m);
 m--;
}
else
printf(" ");

}
l--;
printf("\n");
}


}
