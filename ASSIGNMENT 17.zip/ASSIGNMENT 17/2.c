#include<stdio.h>
#include<string.h>

main()
{
    char str[100];

char c;
    printf("Enter the string: ");
    gets(str);
    printf("Enter the character: ");
   scanf("%c",&c);

    // calculating length of the string
    int len =strlen(str);
int count=0;
    int i;
    for(i=0;i<=len-1;i++)
    {
       if(c==str[i])
        count++;

    }
printf("Occurence of %c is: %d",c,count);



}
