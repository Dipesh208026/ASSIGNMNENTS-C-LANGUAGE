main()
{

char str[100];
printf("Enter the string: ");
gets(str);

char vowel[10]={'a','e','i','o','u','A','E','I','O','U'};
int len=strlen(str);
int i,j;
char *p;
char *q;
q=vowel;
p=str;
int v=0;
int c=0;
for(i=0;*(p+i);i++)
{
for(j=0;j<=9;j++)
{
if(*(p+i)==*(q+j))
v++;


}
}
printf("Number of vowels are: %d\n",v);
printf("Number of consonants are: %d",len-v);

}
