main()
{
char str[100];
 printf("Enter the upper case string: ");
 gets(str);
 int len=strlen(str);
 int i;
 char capital[100];
for(i=0;i<=len-1;i++)
{
if(str[i]!=32)
{int a= str[i];
int c=a+32;
capital[i]=c;
}
}

 for(i=0;i<=len-1;i++)
 {
 printf("%c",capital[i]);
 }


 }
