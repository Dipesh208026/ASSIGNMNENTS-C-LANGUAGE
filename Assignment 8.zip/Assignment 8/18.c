main()
{
int i,j;
int k=-1;
int m= 4;
for(i=1;i<=17;i++)
{
if(i%2!=0&&i<=9)
{

k++;
for(j=1;j<=9;j++)
{
if(i>=1&&i<=9&&j<=5+k&&j>=5-k)
printf("*");
else
printf(" ");

}

}

else if(i%2!=0&&i>=11)
{
    m--;
    for(j=1;j<=9;j++)
{


 if(i>=11&&i<=17&&j<=5+m&&j>=5-m)
printf("*");


else
printf(" ");
}

}
printf("\n");
}
}
