int natural(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int b=2*a-1;
int sum=natural(b);

printf("%d",sum);
}
int natural(int a)
{

if(a==1)
    return 1;

int sum=a+natural(a-2);
return(sum);

}
