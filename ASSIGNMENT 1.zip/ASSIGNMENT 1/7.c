main()
{

printf("%%d");

}
