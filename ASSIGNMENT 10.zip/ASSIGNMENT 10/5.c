void naturalnumber(int c);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
naturalnumber(a);
}

void naturalnumber(int c)
{
int i;


for(i=1;i<=2*c;i++)
{

    if(i%2!=0)
          printf("%d \n",i);
}


}


