main()
{
int n;
int i;
printf("Enter the number: ");
scanf("%d",&n);
for(i=n;i>=1;i--)
{printf("%d \n",i);

}

}
