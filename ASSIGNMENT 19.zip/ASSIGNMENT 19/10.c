#include<stdio.h>
#include<string.h>

main()
{
int n;
char data[100][2][100];
printf("Enter the number of students: ");
scanf("%d",&n);
fflush(stdin);
int i,j;
for(i=0;i<=n-1;i++)
{
for(j=0;j<=1;j++)
{
if(j==0)
{printf("Enter the %d student Username: ",i+1);
gets(data[i][j]);}
else if(j==1)
{printf("Enter the %d student Password: ",i+1);
gets(data[i][j]);}
}
}
printf("%s\n",data[0][0]);
printf("%s",data[0][1]);

printf("\n");
printf("Please login!!");
printf("----------------");
printf("\n");
char checkuser[100];
char checkpass[100];
printf("Please enter the USERNAME: ");
gets(checkuser);
printf("Please enter the Password: ");
gets(checkpass);
int flag=0;
for(i=0;i<=n-1;i++)
{

    if(strcmp(data[i][0],checkuser)==0 && strcmp(data[i][1],checkpass)==0)
    {printf("Hence LOGIN SUCCESSFUL");
    flag=1;
    break;
    }

}
if(flag==0)
{
    printf("----------------------------------------------")
    printf("PASSWORD OR USERNAME IS INCORRECT, LOGIN FAILED!!");
}





}
