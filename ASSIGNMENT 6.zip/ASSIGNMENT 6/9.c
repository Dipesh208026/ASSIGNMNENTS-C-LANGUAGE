main()
{
int a,b;
printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);

int max=a>b?a:b;

while(1)
{
if(max%a==0&&max%b==0)
{printf("LCM IS %d",max);
break;
}

max++;
}


}
