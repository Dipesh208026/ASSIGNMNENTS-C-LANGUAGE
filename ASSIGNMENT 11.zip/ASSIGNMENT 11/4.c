#include <stdio.h>
#include <conio.h>
// TAKE SOMETHING AND RETURN SOMETHING
int number(int y);
int main (){
int x;

printf("Enter the number :");
scanf("%d",&x);

number(x);




}

int number(int a)
{




  int x, i= 2, z;
int b=a+1;

  while(a <= b)
  {
    z = 0;
    x = 1;
    while(x<=b)
    {
      if(b%x == 0)
      {
        z++;

      }
      x++;
    }
if(z==2)
	{
	    printf(" %d ", b);
    break;
    }
else
    b++;

  }


}
