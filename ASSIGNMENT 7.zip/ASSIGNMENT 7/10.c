main()
{
int a,last,y,i;
for(a=100;a<=999;a++)
{
int sum=0;
for(i=a;i!=0;y++)
{
last=i%10;
i=i/10;
int mul=last*last*last;
sum=sum+mul;

}
if(sum==a)
printf(" %d ",sum);

}



}
