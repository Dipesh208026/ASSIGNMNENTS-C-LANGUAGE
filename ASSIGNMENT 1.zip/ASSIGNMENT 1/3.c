main()
{

printf("\"MySirG\""); // using \"....\"

}
