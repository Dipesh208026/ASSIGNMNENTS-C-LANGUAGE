void sort(int *p,int n);
main()
{
int n;
printf("Enter the no. of values: ");
scanf("%d",&n);

int a[100];
int i;
for(i=0;i<=n-1;i++)
{
printf("Enter the %d value: ",i+1);
scanf("%d",&a[i]);

}
printf("Before sorting-----\n");
for(i=0;i<=n-1;i++)
{
    printf("%d ",a[i]);
}
printf("\n");
printf("After sorting-------\n");
sort(a,n);
for(i=0;i<=n-1;i++)
{
    printf("%d ",a[i]);
}

}

void sort(int *p,int n)
{
    int i,j,temp;
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<=n-1;j++)
        {
            if(*(p+i)>=*(p+j))
        {
            temp=*(p+j);
            *(p+j)=*(p+i);
            *(p+i)=temp;

        }


        }



    }


}
