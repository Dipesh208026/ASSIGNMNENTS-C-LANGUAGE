main()
{
char x;
int a,b,c;
float h,e,f;


printf("CHOOSE ANY ONE OPTION: \n");
printf("a. Addition \n");
printf("b. Subtraction \n");
printf("c. Multiplication \n");
printf("d. Division \n");
printf("e. Exit \n");
printf("\n");

scanf("%c",&x);
int y=x;

switch(y)
{

case 'a':

printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);
 c=a+b;
printf("Sum is : %d",c);
break;

case 'b':

printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);
c=a-b;
printf("Difference is : %d",c);
break;

case 'c':
printf("Enter the first number: ");
scanf("%d",&a);
printf("Enter the second number: ");
scanf("%d",&b);
c=a*b;
printf("Sum is : %d",c);
break;

case 'd':
printf("Enter the first number: ");
scanf("%f",&e);
printf("Enter the second number: ");
scanf("%f",&f);
h=e/f;
printf("Sum is : %f",h);
break;

case 'e':
return(0);







}


}
