int check(int a,int b);
main()
{
int a,b;
printf("Enter the number: ");
scanf("%d",&a);
printf("Enter the digit");
scanf("%d",&b);
int x=check(a,b);
if(x==1)
printf("Yes  NUMBER EXISTS..");
else if(x==0)
printf("No NUMBBER DO NOT EXITS...");
}

int check(int a,int b)
{
int x;
int e;
int c=1;
int d=0;
while(a!=0)
{
e=a%10;
a=a/10;
if(a==b)
{
return(c);
}

}
return(d);

}
