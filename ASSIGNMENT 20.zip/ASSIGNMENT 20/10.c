main()
{
char a[100];
int i,n;
printf("Enter the string: ");
gets(a);
n=strlen(a);
int j;
char *p;
p=a;
char temp;
j=n-1;

for(i=0;i<=j;i++)
{
temp=*(p+i);
*(p+i)=*(p+j);
*(p+j)=temp;
j--;
}
printf("Final string is: %s ",a);



}
