int count(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);

int b=count(a);
printf("%d",b);
}
int count(int a)
{
int sum=0;
int c=0;
int q,r;

if(a==0)
return;
q=a/10;
r=a%10;
a=q;
int b=count(a);
b++;
return b;
}
