#include<stdio.h>
#include<string.h>
void repeated(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
repeated(str,len);
}
void repeated(char str[],int len)
{
int count;
int i,j;
for(i=0;i<len-1;i++)
{
    count=0;
for(j=i+1;j<=len-1;j++)
{

if(str[i]==str[j])
count++;

}

if(count>=1)
printf("%c is repeated\n",str[i]);


}




}
