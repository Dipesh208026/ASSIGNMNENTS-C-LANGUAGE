void compare(char str1[],char str2[],int len1,int len2);
main()
{
 char str1[100],str2[100];
 printf("Enter the first string: ");
 gets(str1);
 printf("Enter the second string: ");
 gets(str2);

 int len1=strlen(str1);
 int len2=strlen(str2);
compare(str1,str2,len1,len2);
}

void compare(char str1[], char str2[],int len1,int len2)
{

int i,count=0;
if(len1!=len2)
    printf("String are not same!");
else if(len1==len2)
{
for(i=0;i<=len1-1;i++)
{
    if(str1[i]==str2[i])
        count++;



}

if(count=len1+1)
    printf("Strings are SAME");


}
}
