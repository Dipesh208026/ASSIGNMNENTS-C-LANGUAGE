
#include<stdio.h>
main()
{
int *p;
p=(int*)(malloc(sizeof(int)));
printf("Enter the bytes: ");
scanf("%d",p);
if(p==NULL)
{
    printf("Memory allocation Failed \n");

}
else
    printf("Memory allocation is sucessful");

}
