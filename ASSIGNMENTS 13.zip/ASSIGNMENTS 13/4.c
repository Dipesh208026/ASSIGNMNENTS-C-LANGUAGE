int natural(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int sum=natural(a);
printf("%d",sum);
}
int natural(int a)
{
if(a==0)
    return 0;
int sum=a*a+natural(a-1);
return(sum);

}
