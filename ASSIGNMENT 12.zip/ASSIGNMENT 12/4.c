main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);

natural(a);

}
void natural(int a)
{

if(a==0)
return;
printf("%d\n",2*a-1);
natural(a-1);






}
