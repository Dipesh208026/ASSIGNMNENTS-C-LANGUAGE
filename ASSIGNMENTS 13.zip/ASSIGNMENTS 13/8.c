

int fibbo(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int b,i;
for(i=1;i<=a;i++) // loop chalaya hai kyunki hame a ke phele ke bhi toh term chahiye....
{
   b=fibbo(i);
printf("%d\t",b);
}

}

int fibbo(a)
{
if(a==0)
    return 0;
    else if(a==1||a==2)
        return 1;
int s=fibbo(a-2)+fibbo(a-1);
return s;

}
