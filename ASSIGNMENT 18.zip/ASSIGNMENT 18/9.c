#include<stdio.h>
#include<string.h>
void wordrev(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
wordrev(str,len);
}
void wordrev(char str[],int len)
{
int start=0;
int end=0;
int i,j,m,l;
char temp;

for(i=0;i<=len;i++)
{

        if(str[i]==32)
        {


             j=i-1;

            for(m=start;m<=j;m++)
            {


                 temp=str[m];
                str[m]=str[j];
                str[j]=temp;
                j--;
            }

        start=i+1;

        }
       else if(str[i]=='\0')
        {


             j=i-1;

            for(l=start;l<=j;l++)
            {

                 temp=str[l];
                str[l]=str[j];
                str[j]=temp;
                j--;
            }

        start=i+1;

        }


}
char temp1;
int k=len-1;
for(i=0;i<=k;i++)

{
    temp1=str[i];
    str[i]=str[k];
    str[k]=temp1;
    k--;
}
printf("%s",str);



}
