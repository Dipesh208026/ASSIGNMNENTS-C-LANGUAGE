main()
{
int a;
float charge;
printf("Enter the units consumed: ");
scanf("%d",&a);

 float sum=0;;
switch(a)
{

case 0 ... 50:

sum=(float)sum+0.50*a;
charge= 0.2*sum+sum;
printf("%.2f",charge);
break;

case 51 ... 150:

sum=(float)sum+0.75*a;
charge= 0.2*sum+sum;
printf("%.2f",charge);
break;
case 151 ... 250:

sum=(float)sum+ 1.20*a;
charge= 0.2*sum+sum;
printf("%.2f",charge);
break;

default:
sum=(float)sum+ 1.50*a;
charge= 0.2*sum+sum;
printf("%.2f",charge);
break;




}





}
