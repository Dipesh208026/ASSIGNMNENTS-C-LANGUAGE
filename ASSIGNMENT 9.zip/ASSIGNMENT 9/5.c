main(){

int x;
printf("Please enter the number: ");
scanf("%d",&x);

switch(x)
{

case 1:
printf("Good");
break;

case 2:
printf("Better");
break;
case 3:
printf("Best");
break;
case 4:
printf("Invalid ");
break;
default:
printf("Please enter numbers between 1 and 4");
}
}
