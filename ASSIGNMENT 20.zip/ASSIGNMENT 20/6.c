main()
{

char str[100];
printf("Enter the string of your choice: ");
gets(str);

int i;
char *p=str;

for(i=0;*(p+i);i++);
printf("Length of your string is: %d",i);




}
