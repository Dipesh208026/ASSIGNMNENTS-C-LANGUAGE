main()
{
char x;
int a,b,c;
float h,e,f;


printf("CHOOSE ANY ONE OPTION: \n");
printf("a. Check whether a given set of three numbers are length of an isosceles triangle or not. \n");
printf("b. Check whether a given set of three numbers are lengths of slides of a right angled triangle or not \n");
printf("c. Check whether a given set of three numbers are equilaterak triangle or not. \n");
printf("d. Exit \n");
printf("\n");

scanf("%c",&x);
int y=x;

switch(y)
{

case 'a':

printf("Enter the length of first side:");
scanf("%d",&a);
printf("Enter the length of Second side:");
scanf("%d",&b);
printf("Enter the length of Third side:");
scanf("%d",&c);

if(a==b&&a==c&&c==b)
printf("Not Isosceles triangle ");

else if(a==b||a==c||b==c)
printf(" ISOSCELES TRIANGLE ");

else
printf("NOT ISOSCELES TRIANGLE ");
break;


case 'c':

printf("Enter the length of first side:");
scanf("%d",&a);
printf("Enter the length of Second side:");
scanf("%d",&b);
printf("Enter the length of Third side:");
scanf("%d",&c);

if(a==b&&a==c&&c==b)
printf("Equilateral triangle ");
else
    printf("NOT EQUILATERAL TRAINGLE ");
break;

case 'd':
return(0);

case 'b':

printf("Enter the length of BASE side:");
scanf("%d",&a);
printf("Enter the length of PERPENDICULAR side:");
scanf("%d",&b);
printf("Enter the length of HYPOTENUSE side:");
scanf("%d",&c);

if(a>b||a>c)
printf("RIGHT ANGLE TRIANGLE");

else if(c>a&&c>b)
    printf("RIGHT ANGLE TRIANGLE");

else
    printf("NOT RIGHT ANGLED TRIANGLE");






}
}

