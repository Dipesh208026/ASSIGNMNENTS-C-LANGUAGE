#include <stdio.h>
#include <conio.h>
// prime number between two numbers
// TAKE SOMETHING AND RETURN NOTHING
void number(int a,int b);
int main (){
int x;
int y;

printf("Enter the number :");
scanf("%d",&x);
printf("Enter the number :");
scanf("%d",&y);
number(x,y);




}

void number(int a,int b)
{

a=a+1;


  int x, i= 2, z;


  while(a < b)
  {
    z = 0;
    x = 1;
    while(x<=a)
    {
      if(a%x == 0)
      {
        z++;

      }
      x++;
    }
if(z==2)
	printf(" %d ", a);
    a++;
  }







}

