int greatest(int b[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
c= greatest(a,n);
printf("%d",c);
}

int greatest(int b[],int n)

{

int i,j,c;


for(j=0;j<=n-1;j++)
{
if(b[0]<=b[j])
{
c=b[j];
b[j]=b[i];
b[i]=c;

}


}



return b[0];


}
