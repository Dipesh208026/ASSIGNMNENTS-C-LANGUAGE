main()
{

int i,n;
int a[10];
printf("Enter the no. of values: ");
scanf("%d",&n);
printf("Enter the %d numbers :",n);
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);
}
int b;
int j;
for(i=0;i<=n-1;i++)
{


for(j=i+1;j<=n-1;j++)
{
if(a[i]>=a[j])
{
b=a[i];
a[i]=a[j];
a[j]=b;

}

}}
printf("Second largest number is %d",a[n-2]);

}
