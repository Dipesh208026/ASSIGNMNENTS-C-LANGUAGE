#include<stdio.h>
main()
{
char str[100];
printf("Enter the String: ");
fgets(str,100,stdin);

// for calculating the length of the string
int b=strlen(str);
// removing the new line character by replacing with NULL CHARACTER
str[strlen(str)-1]='\0';
int c=strlen(str);
printf("%d",c);
}

