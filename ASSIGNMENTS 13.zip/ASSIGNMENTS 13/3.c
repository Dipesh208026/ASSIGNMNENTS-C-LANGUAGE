int natural(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
int b=2*a;
int sum=natural(b);

printf("%d",sum);
}
int natural(int a)
{

if(a==2)
    return 2;

int sum=a+natural(a-2);
return(sum);

}
