#include<stdio.h>
#include<string.h>



struct time
{

int hour;
int minute;
int second;
};

struct time input(int);
void display(struct time );
struct time difference(struct time b1[]);

 main()
{
struct time b1[100];
struct time b2;
int i;
for(i=0;i<=1;i++)
{
    b1[i]=input(i);
}

b2=difference(b1);

printf("\n");

display(b2);

printf("\n");

}

struct time input(int i)
{
struct time b1;
if(i==0)
printf("Enter the start time: \n");
else if(i==1)
  printf("Enter the end time: \n");
printf("Hours : ");
scanf("%d",&b1.hour);
printf("Minutes: ");
scanf("%d",&b1.minute);
printf("Seconds: ");
scanf("%d",&b1.second);
return b1;


}

struct time difference(struct time b4[])
{
struct time b5;
if(b4[1].second<b4[0].second)
{
b4[1].second=b4[1].second+60;

b4[1].minute--;

}
else if(b4[1].minute<b4[0].minute)
{
b4[1].minute=b4[1].minute+60;
b4[1].hour--;

}



b5.second=b4[1].second-b4[0].second;
b5.minute=b4[1].minute-b4[0].minute;
b5.hour=b4[1].hour-b4[0].hour;


return b5;

}


void display(struct time b3)
{
printf("AFTER TIME DIFFERENCE: \n");
printf("%d : %d : %d",b3.hour,b3.minute,b3.second);


}
