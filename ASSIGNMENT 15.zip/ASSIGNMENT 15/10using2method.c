
void frequency(int a[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
frequency(a,n);

}
void frequency(int a[],int n)
{
int temp;
int i;
int c[11];

for(i=0;i<=10;i++)
{
c[i]=0;

}

for(i=0;i<=n-1;i++)
{
temp=a[i];
c[temp]++;


}
for(i=0;i<=10;i++)
{
    if(c[i]!=0)
        printf("Frequency of %d is : %d\n",i,c[i]);

}



}
