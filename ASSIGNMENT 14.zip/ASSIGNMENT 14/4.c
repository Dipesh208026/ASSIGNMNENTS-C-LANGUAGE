main()
{

int i,n;
int a[10];
printf("Enter the no. of values: ");
scanf("%d",&n);
printf("Enter the %d numbers :",n);
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);
}

int b;
for(i=0;i<=n-1;i++)
{
if(a[0]<=a[i])
b=a[i];
a[i]=a[0];
a[0]=b;

}

printf("Largest number is %d",a[0]);
}
