void duplicate(int a[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
duplicate(a,n);

}

void duplicate(int a[],int n)
{
int temp=0;
int count=0;
int i,j;

for(i=0;i<=n-1;i++)
{
if(a[i]==a[i+1])
{printf("%d",a[i]);
temp=0;
    break;}
    else
    temp=1;

}
if(temp==1)
    printf("No occurence available");





}








