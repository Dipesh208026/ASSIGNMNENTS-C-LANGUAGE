int main()
{
int a,b;
printf("Enter the time in this format \" HH:MM\" " );
scanf("%d:%d",&a,&b);
printf(" %d hour and %d Minute ",a,b);
}
