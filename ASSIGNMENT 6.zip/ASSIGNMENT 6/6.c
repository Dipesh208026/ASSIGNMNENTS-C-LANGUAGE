main(){
int i,n;
printf("Enter the number: ");
scanf("%d",&n);
int fact=1;
for(i=1;i<=n;i++)
{

fact=i*fact;


}
   printf("Fctorial is %d",fact);

}
