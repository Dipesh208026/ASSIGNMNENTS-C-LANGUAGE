main()
{

int i,n;
int a[100];
printf("Enter the no. of values: ");
scanf("%d",&n);
printf("Enter the %d numbers :",n);
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);
}
printf("New array \n");
int b[100];
for(i=0;i<=n-1;i++)
{

b[i]=a[i];
printf("%d\t",a[i]);


}
for(i=0;i>=n-1;i--)
{


printf("%d\t",b[i]);


}



}
