#include<stdio.h>
main()
{
 char str[10][100];
 char palin[100];

 int i,j,n,m,k;
 int count;
 printf("Enter the no. of words: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d word: ",i+1);
 gets(str[i]);
}
printf("\n");
printf("PALINDROME WORDS ARE: \n");
printf("--------------------------\n");

for(i=0;i<=n-1;i++)
{
count =0;
int len=strlen(str[i]);
k=palindrome(str[i],len);

if(k==1)
    printf("%s\n",str[i]);

}
}
int palindrome(char str[],int len)
{
int i;
int count=0;
int j=len-1;

for(i=0;i<=j;i++)
{
if(str[i]==str[j])
{count++;
}
j--;
}
if(i==count)
return(1);
else
return(0);
}








