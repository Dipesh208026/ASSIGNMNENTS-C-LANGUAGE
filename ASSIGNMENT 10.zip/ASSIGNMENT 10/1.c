int circle(int a);
main()
{
int a ;
printf("Enter the radius : ");
scanf("%d",&a);

float b=(float)circle(a);
printf("%.2f",b);

}

int circle(int a)
{

float c=(float)(3.14*a*a);
return(c);

}
