naturalnumber(int c);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
naturalnumber(a);
}

naturalnumber(int c)
{
int i;
for(i=1;i<=c;i++)
printf("%d \n",i);



}
