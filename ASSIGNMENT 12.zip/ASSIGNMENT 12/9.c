void octal(int);
main()
{

int a;
printf("Enter the number: ");
scanf("%d",&a);

octal(a);
}
octal(int a )
{

int q;
int r;

if(a==0)
return;
q=a/8;
r=a%8;
a=q;
octal(a);
printf("%d",r);



}
