int power(int a,int b);
main()
{
int a,b;
printf("Enter the base: ");
scanf("%d",&a);
printf("Enter the power: ");
scanf("%d",&b);

int c=power(a,b);
printf("%d",c);
}
int power(int a,int b)
{

if(b==0)
return 1;
int ans=(a*power(a,b-1));
return ans;


}
