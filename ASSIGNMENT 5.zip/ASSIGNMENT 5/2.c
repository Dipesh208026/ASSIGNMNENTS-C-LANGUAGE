main()
{
int n;
int i;
printf("Enter the number: ");
scanf("%d",&n);
for(i=1;i<=n;i++)
{printf("%d \n",i);

}

}
