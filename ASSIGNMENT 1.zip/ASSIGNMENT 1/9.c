main()
{
printf("\\\\");

}
