#include<stdio.h>
#include<string.h>
void upper(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
upper(str,len);
}
char t;
void upper(char str[],int len)
{

int i;
int c;
for(i=0;i<=len-1;i++)
{

if(str[i]>='a'&&str[i]<='z'&&str[i]!=32)
{c=str[i];
int b=c-32;
str[i]=b;
}

}


printf("%s",str);







}
