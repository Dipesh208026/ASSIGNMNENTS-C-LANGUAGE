
main()
{

char a;
printf("Enter the Character: ");
scanf("%c",&a);
if(a>='a'&&a<='z')
printf("LOWER CASE");
else if(a>='A'&&a<='Z')
{
printf("UPPER CASE");
}
else
printf("digit or special characters");

}





