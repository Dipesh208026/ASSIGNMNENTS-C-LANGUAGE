int main()
{
  int x, i= 2, z;


  while(i <= 100)
  {
    z = 0;
    x = 1;
    while(x<=i)
    {
      if(i%x == 0)
      {
        z++;

      }
      x++;
    }
    if(z<=2)
    {
	printf(" %d ", i);
    }
    i++;
  }

}
