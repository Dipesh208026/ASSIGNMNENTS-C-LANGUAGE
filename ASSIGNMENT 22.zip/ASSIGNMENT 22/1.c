#include<stdio.h>
main()
{
    int i;
    int j=1;
    char *p;
    p=(char*)malloc(sizeof(char));
    char c;
    printf("Enter the string: ");

    for(i=0;c!='\n';i++)
    {
        c=getc(stdin);
        j++;
       p=(char*)realloc(p,j*sizeof(char));
       p[i]=c;

    }

p[i]='\0';

printf("Entered string is: %s",p);
free(p);

}


