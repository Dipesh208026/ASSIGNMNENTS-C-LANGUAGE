#include<stdio.h>
#include<string.h>
main()
{
    printf("Please Enter only the Square matrix: \n");
int a,b;
printf("Enter the number of rows: ");
scanf("%d",&a);
printf("Enter the number of columns: ");
scanf("%d",&b);
fflush(stdin);
int i,j;
int c[10][10][10];
int m;

for(m=0;m<=0;m++)
{
  printf("For %d matrix: \n",m+1);
for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{

printf("Enter the %d row %d column element: ",i+1,j+1);
scanf("%d",&c[m][i][j]);
}

}
printf("\n");
for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{
printf("%d ",c[m][i][j]);

}
printf("\n");

}
}
int d[0][20];
// for assign "zero" to  the  2 matrix values;
int y;
for(i=0;i<=a-1;i++)
{
y=0;
    for(j=0;j<=a-1;j++)
    {
        if(c[0][i][j]==1)
        y++;

    }


d[0][i]=y;
}
int temp;
for(i=0;i<a-1;i++)
{

    for(j=i+1;j<=a-1;j++)
    {
        if(d[0][i]>=d[0][j])
        temp=d[0][i];
        d[0][i]=d[0][j];
        d[0][j]=temp;



    }



}



printf("MAXIMUM NO. OF 1s in %d ROW ",d[0][0]);





}























