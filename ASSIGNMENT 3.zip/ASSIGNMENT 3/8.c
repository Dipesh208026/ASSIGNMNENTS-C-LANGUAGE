main()
{

int a;
printf("enter the Year ");
scanf("%d",&a);
if(a%100==0&&a%400==0)
printf("LEAP YEAR");
else if(a%4==0)

{printf("LEAP YEAR");}
else
printf("NOT A LEAP YEAR");



}
