main()
{
int n;
int i;
printf("Enter the number: ");
scanf("%d",&n);
for(i=1;i<=2*n;i++)

{
if(i%2!=0)
{
printf("%d \n",i);
}
}

}
