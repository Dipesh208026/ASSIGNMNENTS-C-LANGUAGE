main()
{
int i,j;
for(i=1;i<=4;i++)
{
int  k=1;
 int l=5-i;
 int m=3;
for(j=1;j<=7;j++)
{

if(j>=1&&j<=5-i)
{printf("%d",k);
k++;}
else if(i>=2&&j>=3+i&&j<=7)
{

 printf("%d",l);
 l--;
}

else if(i==1&&j>4&&j<=7)
{
    printf("%d",m);
m--;}
else
printf(" ");

}
printf("\n");
}


}
