main()
{
char str[100];
 printf("Enter the  string: ");
 gets(str);
 int len=strlen(str);
 int i=0;

 int count1=0,count2=0,count3=0;
for(i=0;i<=len-1;i++)
{
if(str[i]>='a'&&str[i]<='z'||str[i]>='A'&&str[i]<='Z')

count1++;

else if(str[i]>=48&&str[i]<=57)
    count2++;
else
    count3++;



}
printf("No of Alphabets are: %d\n",count1);


printf("No of Digits are: %d\n",count2);


printf("No of Special characters are: %d\n",count3);



 }
