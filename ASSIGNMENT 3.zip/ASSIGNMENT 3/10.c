main()
{
int a,b;
printf("Enter the cost price: ");
scanf("%d",&a);
printf("Enter the selling price: ");
scanf("%d",&b);
float profit=(float)b-a;
float profit1=(float)profit/a;
float perc=(float)profit1*100;
printf(" profit percentage %.2f",perc);


}
