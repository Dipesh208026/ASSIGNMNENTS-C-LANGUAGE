int main()
{
        int a;
    printf("Enter first number: ");
    scanf("%d",&a);


  int x, i= 2, z;
int b=a+1;

  while(a <= b)
  {
    z = 0;
    x = 1;
    while(x<=b)
    {
      if(b%x == 0)
      {
        z++;

      }
      x++;
    }
if(z==2)
	{
	    printf(" %d ", b);
    break;
    }
else
    b++;

  }

}
