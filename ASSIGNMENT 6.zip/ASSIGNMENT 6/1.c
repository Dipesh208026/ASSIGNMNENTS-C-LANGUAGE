main(){
int i,n;
printf("Enter the number: ");
scanf("%d",&n);
int sum=0;
for(i=0;i<=n;i++)
{
   sum=sum+i;

}
   printf("Sum is %d",sum);

}
