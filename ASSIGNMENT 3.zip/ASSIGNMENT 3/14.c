main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a%3==0||a%7==0)
printf("NUMBER IS DIVISIBLE BY 7 OR 3");
else
printf("NUMBER IS NOT DIVISIBLE BY 7 OR 3");



}
