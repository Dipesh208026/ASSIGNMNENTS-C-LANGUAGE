main()
{
int i,j;
for(i=1;i<=4;i++)
{
int  k=1;
int l=i-1;
for(j=1;j<=7;j++)
{
if(j>4-i&&j<5)
{printf("%d",k);
k++;}
else if(i>1&&j>=5&&j<4+i)
{
 printf("%d",l);
 l--;
}
else
printf(" ");

}
printf("\n");
}


}
