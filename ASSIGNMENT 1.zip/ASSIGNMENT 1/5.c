main()
{
int a;
a=printf("Dipesh kumar");// printing length using printf function
printf("%d ",a);
}
