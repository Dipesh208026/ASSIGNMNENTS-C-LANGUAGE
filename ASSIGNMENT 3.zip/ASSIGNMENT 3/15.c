main()
{

int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a>0)
printf("NUMBER IS POSITIVE");
else if(a<0)
printf("NUMEBR IS NEGATIVE");
else if(a==0)
printf("NUMBER IS ZERO");


}
