main()
{
int number[100];
int i,n;
printf("Enter the no. of digits: ");
scanf("%d",&n);
for(i=0;i<=n-1;i++)
{
    printf("Enter the %d number: ",i+1);
    scanf("%d",&number[i]);
}

int *p;
p=number;
int temp;
int j=n-1;

for(i=0;i<=j;i++)
{

temp=*(p+i);
*(p+i)=*(p+j);
*(p+j)=temp;
j--;
}
printf("Reverse order is :\n");
printf("-------------------\n");
for(i=0;*(p+i);i++)
{
    printf("%d\t",*(p+i));
}


}
