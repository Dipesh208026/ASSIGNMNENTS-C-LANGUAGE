main()
{
int a,b,c,d,e;
printf("Enter the marks of 1st subject:");
scanf("%d",&a);
printf("Enter the marks of 2nd subject:");
scanf("%d",&b);
printf("Enter the marks of 3rd subject:");
scanf("%d",&c);
printf("Enter the marks of 4th subject:");
scanf("%d",&d);
printf("Enter the marks of 5th subject:");
scanf("%d",&e);

if(a>=33&&b>=33&&c>=33&&d>=33&&e>=33)
printf("YOU HAVE PASSED");
else
printf("YOU HAVE FAILED");


}
