main()
{
char str[100];
 printf("Enter the string: ");
 gets(str);
 int len=strlen(str);
 int i,j;
 int count=0;
 char vowel[10]={'a','e','i','o','u','A','E','I','O','U'};
 for(i=0;i<=len-1;i++)
 {
    for(j=0;j<=9;j++)
    {
       if(str[i]==vowel[j])
 count++;
    }


 }
printf("NO. OF VOWELS ARE : %d",count);






}
