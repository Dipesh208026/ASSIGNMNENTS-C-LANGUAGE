main()
{
int i,j;
for(i=1;i<=4;i++)
{
int  k=1;
 int l=4-i;
for(j=1;j<=7;j++)
{

if(j>=i&&j<=4)
{printf("%d",k);
k++;}
else if(i<4&&j>4&&j<=8-i)
{

 printf("%d",l);
 l--;
}
else
printf(" ");

}
printf("\n");
}


}
