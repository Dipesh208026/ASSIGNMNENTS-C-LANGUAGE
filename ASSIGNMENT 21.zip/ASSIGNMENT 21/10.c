#include<string.h>
#include<stdio.h>
struct marks input(int i);
void display(struct marks b2,int i);
struct marks
{

int roll_no;
char name[100];
int chem_marks;
int maths_marks;
int phy_marks;

};
main()
{
int n,i;
struct marks b2[100];
printf("Enter the number of students: ");
scanf("%d",&n);
for(i=0;i<=n-1;i++)
{
    b2[i]=input(i);
}
printf("\n");
for(i=0;i<=n-1;i++)
{
display(b2[i],i);

}
}
struct marks input(int i)
{
struct marks b1;
printf("Enter the %d student roll_no: ",i+1);
fflush(stdin);
scanf("%d",&b1.roll_no);
fflush(stdin);
printf("Enter the %d student name: ",i+1);
fgets(b1.name,30,stdin);
b1.name[strlen(b1.name)-1]='\0';
printf("Enter the %d chem_marks: ",i+1);
scanf("%d",&b1.chem_marks);
printf("Enter the %d maths_marks: ",i+1);
scanf("%d",&b1.maths_marks);
printf("Enter the %d phy_marks: ",i+1);
scanf("%d",&b1.phy_marks);
return b1;
}

void display(struct marks b2,int i)
{

int sum;
sum=(b2.chem_marks+b2.maths_marks+b2.phy_marks);
float avg= (float)sum/3;
printf("Name -> %s   percentage of student is : %.2f\n",b2.name,avg);


}


