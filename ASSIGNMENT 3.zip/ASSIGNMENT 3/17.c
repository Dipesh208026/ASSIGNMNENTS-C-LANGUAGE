main()
{

int a,b,c;
printf("Enter the first side value: ");
scanf("%d",&a);
printf("Enter the second side value: ");
scanf("%d",&b);
printf("Enter the third side value: ");
scanf("%d",&c);

if((a+b)>c&&(b+c)>a&&(a+c)>c)
printf("VALID TRIANGLE");
else
printf("NOT A VALID TRIANGLE");

}
