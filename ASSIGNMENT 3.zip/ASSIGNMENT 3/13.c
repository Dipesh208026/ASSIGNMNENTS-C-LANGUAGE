main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);
if(a%2==0&&a%3==0)
printf("NUMBER IS DIVISIBLE BY BOTH 2 AND 3");
else
printf("NUMBER IS NOT DIVISIBLE BY 2 OR 3");



}
