#include<stdio.h>
main()
{
 char str[10][100];
 char str1[100];
 int i;
 int n;
 printf("Enter the no. of strings: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d string: ",i+1);
 gets(str[i]);
}
printf("\n");
printf("Enter the string you want to search: ");
gets(str1);
char temp[100];
int j;
int a;
int count=0;
for(i=0;i<=n-1;i++)
{
int a= strcmp(str1,str[i]);
if(a==0)
{
count++;
printf("Yes ! matched with  %d string,",i+1);
break;
}

}
if(count==0)
{


printf("----------------------------\n");
printf("Oops ,No match! \n");
printf("----------------------------");
}


















}
