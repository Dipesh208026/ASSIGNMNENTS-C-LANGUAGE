#include<stdio.h>
#include<string.h>
main()
{
int a,b;
printf("Enter the number of rows: ");
scanf("%d",&a);
printf("Enter the number of columns: ");
scanf("%d",&b);
fflush(stdin);
int i,j;
int c[10][10][10];
int m;

for(m=0;m<=0;m++)
{
  printf("For %d matrix: \n",m+1);
for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{

printf("Enter the %d row %d column element: ",i+1,j+1);
scanf("%d",&c[m][i][j]);
}

}

for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{
printf("%d ",c[m][i][j]);

}
printf("\n");

}
}
// converting the 2nd matrix ( rows into column)
int d[5][5][5];
for(i=0;i<=2;i++)
{
    for(j=0;j<=2;j++)
    {
         d[0][i][j]=c[0][j][i];

    }
}
printf("Transpose matrix: \n");
printf("\n");
for(i=0;i<=2;i++)
{

    for(j=0;j<=2;j++)
    {

       printf("%d  ",d[0][i][j]);

    }

    printf("\n");
}
}
