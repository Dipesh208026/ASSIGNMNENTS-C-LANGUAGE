#include<stdio.h>
#include<string.h>
main()
{
 char str[10][100];
 int i;
 int n;
 printf("Enter the no. of email address: ");
 scanf("%d",&n);
fflush(stdin);
 for(i=0;i<=n-1;i++)
 {
 printf("Enter the %d email: ",i+1);
 gets(str[i]);

}
 printf("\n");
 printf("Wrong emails are: \n");
int c;
for(i=0;i<=n-1;i++)
{
c=strchr(str[i],'@');
if(c==0)

printf("%s\n",str[i]);






}






}
