void series(int a);
int fact(int a);
main()
{
int a;
printf("Enter the number: ");
scanf("%d",&a);

series(a);

}
void series(int a)
{
int i;
int sum=0;
for(i=1;i<=a;i++)
{

 sum=(fact(i)/i)+sum;

}

printf("%d",sum);
}

int fact(int a)
{
int i;
int fact=1;
for(i=1;i<=a;i++)
{

fact=fact*i;

}
return(fact);
}
