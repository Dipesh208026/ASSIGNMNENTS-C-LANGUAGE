int main()
{


int x= printf("ineuron");
printf("%d",x);
return 0;
}
// ineuron is stored in integer variable 'x' as a constant ;

// and it will return its value as a length
