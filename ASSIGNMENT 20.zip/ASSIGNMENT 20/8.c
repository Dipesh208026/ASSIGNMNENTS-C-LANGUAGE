main()
{
int number[100];
int i,n;
printf("Enter the no. of digits: ");
scanf("%d",&n);
for(i=0;i<=n-1;i++)
{
    printf("Enter the %d number: ",i+1);
    scanf("%d",&number[i]);
}

int *p;
p=number;
int sum=0;
for(i=0;*(p+i);i++)
{
    sum=sum+*(p+i);


}

printf("Sum of the numbers are: %d",sum);



}
