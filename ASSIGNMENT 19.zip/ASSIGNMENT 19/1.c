main()
{
 char str[5][100];
 int i;
 for(i=0;i<=4;i++)
 {
 printf("Enter the %d string: ",i+1);
 gets(str[i]);

}
char vowel[100]={'a','e','i','o','u','A','E','I','O','U'};
int j,k;
for(i=0;i<=4;i++)
{
int count=0;
int len=strlen(str[i]);
for(j=0;j<=len-1;j++)
{

for(k=0;k<=9;k++)
{
if(str[i][j]==vowel[k])
count++;
}

}
printf("No. of vowels in %d String is: %d\n",i+1,count);

}





}
