
main()
{

int a,b;
printf("Enter the first number: ");
scanf("%d",&a);
printf("Entere the second number: ");
scanf("%d",&b);
int *p,*q;

p=&a;
q=&b;


if(*p>*q)
printf("Greatest number is %d",*p);
else
printf("Greatest number is %d",*q);




}
