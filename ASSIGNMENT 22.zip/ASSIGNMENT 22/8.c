#include<stdio.h>
main()
{int *p;
p=(int*)malloc(sizeof(int));
*p=10;

printf("Before free %d\n",*p);
free(p);
printf("After free %d\n",*p);

return 0;
}
