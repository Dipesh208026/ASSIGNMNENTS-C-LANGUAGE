
void frequency(int a[],int n);
main()
{
int a[100],n,i,c;
printf("Enter the number of value: ");
scanf("%d",&n);
printf("Enter the values: ");
for(i=0;i<=n-1;i++)
{
scanf("%d",&a[i]);

}
frequency(a,n);

}
void frequency(int a[],int n)
{
int count;
int i,j,temp,k;
for(i=0;i<=n-1;i++)
{
count =0;
temp=0;
for(j=i;j<=n-1;j++)
{
if(a[i]==a[j])
{count++;

}


}
for(k=0;k<=i-1;k++)
{
    if(a[i]!=a[k])
    temp++;

}
if(temp==i)
    printf("frequency of %d is: %d \n",a[i],count);


}


}
