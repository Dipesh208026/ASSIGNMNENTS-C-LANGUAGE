main(){

int x;
printf("Enter the month number: ");
scanf("%d",&x);

switch(x)
{

case 1:
printf("31 DAYS JANUARY");
break;

case 2:
printf(" 28 DAYS FEBRUARY");
break;
case 3:
printf("30 DAYS MARCH");
break;
case 4:
printf("31 DAYS APRIL");
break;
case 5:
printf("30 DAYS MAY");
break;
case 6:
printf("31 DAYS JUNE");
break;
case 7:
printf("30 DAYS JULY");
break;
case 8:
printf("31 DAYS AUGUST");
break;
case 9:
printf("30 DAYS SEPTEMBER");
break;
case 10:
printf("31 DAYS OCTOBER");
break;
case 11:
printf("30 DAYS NOVEMBER");
break;
case 12:
printf("31 DAYS DECEMBER");
break;

}



}
