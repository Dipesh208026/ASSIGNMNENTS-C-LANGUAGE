void swapstr(char *p,char *q,int len1,int len2);
main()
{

char str1[100];
char str2[100];
printf("Enter the first string: ");
gets(str1);
printf("Enter the second string: ");
gets(str2);
int len1=strlen(str1);
int len2=strlen(str2);
printf("Before------\n");
printf("First string is: %s\n",str1);
printf("Second string is %s\n",str2);

printf("After------\n");
swapstr(str1,str2,len1,len2);
printf("First string is: %s\n",str1);
printf("Second string is %s",str2);
}
void swapstr(char *p,char *q,int len1,int len2) // passing address of both the variables
{
int i;
char temp;
for(i=0;*(p+i);i++)
{
temp=*(p+i);
*(p+i)=*(q+i);
*(q+i)=temp;

}



}
