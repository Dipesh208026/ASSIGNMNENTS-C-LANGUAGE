#include<stdio.h>
#include<string.h>
main()
{
    printf("Please Enter only the Square matrix: \n");
int a,b;
printf("Enter the number of rows: ");
scanf("%d",&a);
printf("Enter the number of columns: ");
scanf("%d",&b);
fflush(stdin);
int i,j;
int c[10][10][10];
int m;

for(m=0;m<=0;m++)
{
  printf("For %d matrix: \n",m+1);
for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{

printf("Enter the %d row %d column element: ",i+1,j+1);
scanf("%d",&c[m][i][j]);
}

}
printf("\n");
for(i=0;i<=a-1;i++)
{
for(j=0;j<=b-1;j++)
{
printf("%d ",c[m][i][j]);

}
printf("\n");

}
}

// for addition of  the  2 matrix values;
int sum=0;
int y=0;
for(i=a-1;i>=0;i--)
{

    sum=sum+c[0][y][i];
    y++;
}






printf("\n");

// for printing the final matrix values....


       printf("Sum of Left diagonal of matrix is: %d",sum);




}























