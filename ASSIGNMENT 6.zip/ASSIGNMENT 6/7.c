main(){
int i,n;
printf("Enter the number: ");
scanf("%d",&n);
int last;
int count=0;
while(n!=0)
{

n=n/10;
count++;


}
   printf(" Number of digits are %d",count);

}
