main()
{
int n;
int i;
printf("Enter the number: ");
scanf("%d",&n);
for(i=1;i<=10;i++)

{

printf("%d \n",n*i);

}

}
