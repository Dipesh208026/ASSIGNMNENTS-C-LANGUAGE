main()
{

int a;
int b;
printf("Enter the number: ");
scanf("%d",&a);

switch(a)
{
default:
if(a>=0)
printf("-%d",a);

else if(a<0)
a=a*-1;
    printf("%d",a);
break;

}

}
