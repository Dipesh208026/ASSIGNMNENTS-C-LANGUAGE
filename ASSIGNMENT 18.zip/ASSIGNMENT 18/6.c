#include<stdio.h>
#include<string.h>
void check(char [],int);
main()
{
char str[100];
printf("Enter the string: ");
gets(str);

int len=strlen(str);
check(str,len);
}

void check(char str[],int len)
{

int i;
int c;
int count1=0;
int count=0;
for(i=0;i<=len-1;i++)
{
if(str[i]>='a'&&str[i]<='z'||str[i]>='A'&&str[i]<='Z')
count++;
else if(str[i]>=48&&str[i]<=57)
count1++;
}


if(count>=1&&count1>=1)
printf("THE STRING IS  ALPHANUMERIC");
else
printf("THE STRING IS NOT ALPHANUMERIC");


}
