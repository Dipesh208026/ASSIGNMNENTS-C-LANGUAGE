#include <stdio.h>
#include <conio.h>
// TAKE SOMETHING AND RETURN SOMETHING
long long n(int a);
long long p(int c,int d);
int main (){
int x;
int y;
long long per1,per2;
printf("Enter the total number of items :");
scanf("%d",&x);
printf("Enter the selected items :");
scanf("%d",&y);
per1= n(x);
per2 =p(x,y);
long long pandc=per1/per2;
printf("Answer is : %d \n",pandc);
printf("factorial of n %d \n",per1);
printf("factorial of p %d \n",per2);



}

long long n(int a)
{
long long mul1=1;

int i;
for(i=1;i<=a;i++)

    mul1=mul1*i;
return(mul1);

}
long long p(int a,int b)
{
int final=a-b;
long long mul2=1;

int i;
for(i=1;i<=final;i++)
mul2=mul2*i;
return(mul2);

}

