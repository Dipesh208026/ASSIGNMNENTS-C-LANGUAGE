lcm(int a,int b);
main()
{
int a,b;
printf("Enter the 1st number: ");
scanf("%d",&a);
printf("Enter the 2nd number: ");
scanf("%d",&b);
lcm(a,b);


}
lcm(int a,int b)
{
int max=a>b?a:b;
while(1)
{
if(max%a==0 && max%b==0){
printf("LCM IS %d",max);
break;}
max++;
}


}
